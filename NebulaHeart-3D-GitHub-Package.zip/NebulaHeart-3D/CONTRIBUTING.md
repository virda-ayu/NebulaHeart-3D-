# Contributing

Thank you for your interest in contributing to NebulaHeart 3D.

## Before opening an issue

- Include your operating system and Python version.
- Include the exact command you ran and the complete error message.
- Describe the webcam model/resolution if the issue concerns camera input.
- Do not attach recordings that contain other people without their consent.

## Pull requests

- Keep changes focused and explain the reason for the change.
- Test syntax with `python -m py_compile index_virda_ar_hologram_responsive.py`.
- Update the README if you add or change a gesture or dependency.
- Do not commit virtual environments, recordings, private data, or API credentials.
