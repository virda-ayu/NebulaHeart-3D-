import cv2
import mediapipe as mp
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import math
import threading
import time
from collections import deque, Counter

# ==========================================
# KONFIGURASI & INISIALISASI
# ==========================================
WIDTH, HEIGHT = 1000, 700
NUM_PARTICLES = 1500  

lock = threading.Lock()
shared_data = {
    "mode": 1,
    "target_x": 0.0,
    "target_y": 0.0,
    "target_z": -12.0,
    "frame": None,
    "face_box": None,
    "face_scale": 1.0,
    "face_detected": False,
    "face_tracking_active": False,
    "gesture_name": "MENUNGGU TANGAN",
    "running": True
}

# ==========================================
# GENERASI DATA BENTUK (PARTIKEL 3D)
# ==========================================
pos_space = np.random.uniform(-4.0, 4.0, (NUM_PARTICLES, 3))

# Mode 2: Saturnus (Bola Inti + Cincin)
pos_planet = np.zeros((NUM_PARTICLES, 3))
NUM_SPHERE = 700  
for i in range(NUM_SPHERE):
    phi = np.random.uniform(0, 2 * np.pi)
    costheta = np.random.uniform(-1, 1)
    theta = np.arccos(costheta)
    r = 1.3  
    pos_planet[i, 0] = r * np.sin(theta) * np.cos(phi)
    pos_planet[i, 1] = r * np.sin(theta) * np.sin(phi)
    pos_planet[i, 2] = r * np.cos(theta)

for i in range(NUM_SPHERE, NUM_PARTICLES):
    theta = np.random.uniform(0, 2 * np.pi)
    r = np.random.uniform(1.8, 3.8)  
    pos_planet[i, 0] = r * np.cos(theta)
    pos_planet[i, 1] = np.random.uniform(-0.05, 0.05)  
    pos_planet[i, 2] = r * np.sin(theta)

# Mode 3: Tulisan "I LOVE YOU"
text_img = np.zeros((200, 800), dtype=np.uint8)
cv2.putText(text_img, "I LOVE YOU", (20, 130), cv2.FONT_HERSHEY_SIMPLEX, 3.5, 255, 12, cv2.LINE_AA)
y_indices, x_indices = np.where(text_img > 0)
x_text = (x_indices - 400) / 70.0
y_text = -(y_indices - 100) / 70.0 
z_text = np.random.uniform(-0.1, 0.1, len(x_text))
pos_text = np.zeros((NUM_PARTICLES, 3))
text_points = np.stack((x_text, y_text, z_text), axis=-1)
chosen_indices = np.random.choice(len(text_points), NUM_PARTICLES)
pos_text = text_points[chosen_indices]

# Mode 4: Bentuk Hati / Love
pos_heart = np.zeros((NUM_PARTICLES, 3))
for i in range(NUM_PARTICLES):
    t = np.random.uniform(-np.pi, np.pi)
    p = np.random.uniform(-np.pi, np.pi)
    
    x = 2.0 * (np.sin(t) ** 3)
    y = 2.0 * np.cos(t) - 0.7 * np.cos(2*t) - 0.3 * np.cos(3*t) - 0.1 * np.cos(4*t)
    z = np.sin(p) * 0.4  
    
    pos_heart[i, 0] = x * 0.85
    pos_heart[i, 1] = (y * 0.85) + 0.5  
    pos_heart[i, 2] = z

# Mode 6: Spiral pelangi kosmik untuk gestur tiga jari
pos_rainbow = np.zeros((NUM_PARTICLES, 3))
for i in range(NUM_PARTICLES):
    t = i / NUM_PARTICLES * 10.0 * np.pi
    r = 0.25 + (i / NUM_PARTICLES) * 2.8
    pos_rainbow[i] = [r * np.cos(t), r * np.sin(t), (i / NUM_PARTICLES - 0.5) * 2.2]

# Mode 5: Tulisan "CREATED BY VIRDA AYU" untuk gestur jempol ke atas
# Dibuat dua baris agar tulisan tetap terbaca dalam area partikel 3D.
virda_img = np.zeros((300, 1200), dtype=np.uint8)
cv2.putText(virda_img, "CREATED BY", (115, 115), cv2.FONT_HERSHEY_SIMPLEX,
            2.3, 255, 9, cv2.LINE_AA)
cv2.putText(virda_img, "VIRDA AYU", (175, 245), cv2.FONT_HERSHEY_SIMPLEX,
            2.8, 255, 11, cv2.LINE_AA)
virda_y, virda_x = np.where(virda_img > 0)
virda_points = np.stack(((virda_x - 600) / 95.0,
                         -(virda_y - 150) / 95.0,
                         np.random.uniform(-0.12, 0.12, len(virda_x))), axis=-1)
pos_virda = virda_points[np.random.choice(len(virda_points), NUM_PARTICLES)]

# Mode 7: ledakan partikel saat kedua telapak tangan bertepuk/dekat
pos_clap = np.zeros((NUM_PARTICLES, 3))
for i in range(NUM_PARTICLES):
    direction = np.random.normal(size=3)
    direction /= (np.linalg.norm(direction) + 1e-9)
    radius = np.random.uniform(0.5, 3.2)
    pos_clap[i] = direction * radius

# Mode 8: finger-heart dari ibu jari dan telunjuk
pos_finger_heart = np.zeros((NUM_PARTICLES, 3))
for i in range(NUM_PARTICLES):
    t = np.random.uniform(-np.pi, np.pi)
    z = np.random.uniform(-0.35, 0.35)
    x = 16 * (np.sin(t) ** 3) / 16.0
    y = (13*np.cos(t) - 5*np.cos(2*t) - 2*np.cos(3*t) - np.cos(4*t)) / 16.0
    scale = np.random.uniform(1.5, 2.2)
    pos_finger_heart[i] = [x*scale, y*scale, z]

current_pos = np.copy(pos_space)
target_pos = np.copy(pos_space)

# ==========================================
# FUNGSI LOGIKA DETEKSI GESTUR
# ==========================================
def _jarak_lm(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def _skala_telapak(lm):
    # Jarak wrist ke pangkal jari tengah sebagai pembagi normalisasi.
    return max(_jarak_lm(lm[0], lm[9]), 0.035)


def _jari_lurus(lm, tip, pip, wrist=0):
    # Perbandingan jarak dari wrist lebih toleran terhadap rotasi tangan
    # dibandingkan hanya membandingkan koordinat Y.
    return _jarak_lm(lm[tip], lm[wrist]) > _jarak_lm(lm[pip], lm[wrist]) * 1.12


def _ibu_jari_terbuka(lm, skala):
    # Ibu jari dianggap terbuka bila ujungnya cukup jauh dari pangkal telunjuk.
    return _jarak_lm(lm[4], lm[5]) / skala > 1.05


def hitung_mode_gestur(hand_landmarks):
    lm = hand_landmarks.landmark
    skala = _skala_telapak(lm)

    # Empat jari selain ibu jari.
    index_up = _jari_lurus(lm, 8, 6)
    middle_up = _jari_lurus(lm, 12, 10)
    ring_up = _jari_lurus(lm, 16, 14)
    pinky_up = _jari_lurus(lm, 20, 18)
    fingers = [index_up, middle_up, ring_up, pinky_up]

    thumb_index = _jarak_lm(lm[4], lm[8]) / skala
    other_curled = not any(fingers)

    # 8: Finger Heart / pinch, dengan toleransi relatif terhadap ukuran telapak.
    if thumb_index < 0.42 and other_curled:
        return 8

    # 5: Jempol ke atas / ibu jari terbuka dan empat jari menekuk.
    if _ibu_jari_terbuka(lm, skala) and other_curled:
        # Pastikan ibu jari cenderung mengarah ke atas pada gambar.
        if lm[4].y < lm[2].y + 0.04:
            return 5

    # 6: Tiga jari (telunjuk, tengah, manis) terbuka, kelingking menekuk.
    if index_up and middle_up and ring_up and not pinky_up:
        return 6

    # 4: Kepalan.
    if not any(fingers) and not _ibu_jari_terbuka(lm, skala):
        return 4

    # 2: Hanya telunjuk.
    if index_up and not any(fingers[1:]):
        return 2

    # 3: Peace.
    if index_up and middle_up and not ring_up and not pinky_up:
        return 3

    # 1: Telapak terbuka (semua empat jari dan ibu jari terbuka).
    if all(fingers) and _ibu_jari_terbuka(lm, skala):
        return 1

    return 0


def jarak_tengah_telapak(hand_landmarks_a, hand_landmarks_b):
    # Titik tengah telapak dihampiri dari wrist (0) dan pangkal jari tengah (9).
    a0, a9 = hand_landmarks_a.landmark[0], hand_landmarks_a.landmark[9]
    b0, b9 = hand_landmarks_b.landmark[0], hand_landmarks_b.landmark[9]
    ax, ay = (a0.x + a9.x)/2, (a0.y + a9.y)/2
    bx, by = (b0.x + b9.x)/2, (b0.y + b9.y)/2
    return math.hypot(ax-bx, ay-by)

# ==========================================
# THREAD BACKGROUND: PROSES KAMERA & AI
# ==========================================
def draw_hologram_face(frame, face_landmarks, scale=1.0):
    """Gambar HUD hologram yang mengikuti wajah pada preview webcam."""
    h, w = frame.shape[:2]
    pts = np.array([(int(lm.x * w), int(lm.y * h)) for lm in face_landmarks.landmark], dtype=np.int32)
    x1, y1 = np.min(pts, axis=0)
    x2, y2 = np.max(pts, axis=0)
    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
    bw = max(30, int((x2 - x1) * scale * 1.22))
    bh = max(40, int((y2 - y1) * scale * 1.38))
    x1, x2 = max(0, cx - bw // 2), min(w - 1, cx + bw // 2)
    y1, y2 = max(0, cy - bh // 2), min(h - 1, cy + bh // 2)

    cyan = (255, 230, 40)       # BGR cyan terang
    blue = (255, 120, 20)
    thin = 1
    # Face mesh kontur tipis, seperti pemindaian hologram.
    mp.solutions.drawing_utils.draw_landmarks(
        image=frame,
        landmark_list=face_landmarks,
        connections=mp.solutions.face_mesh.FACEMESH_CONTOURS,
        landmark_drawing_spec=None,
        connection_drawing_spec=mp.solutions.drawing_utils.DrawingSpec(
            color=blue, thickness=1, circle_radius=1
        )
    )
    # Bounding rectangle dan empat sudut bergaya HUD.
    cv2.rectangle(frame, (x1, y1), (x2, y2), cyan, thin, cv2.LINE_AA)
    corner = max(12, min(bw, bh) // 7)
    for x, y, sx, sy in [(x1,y1,1,1),(x2,y1,-1,1),(x1,y2,1,-1),(x2,y2,-1,-1)]:
        cv2.line(frame, (x,y), (x + sx*corner,y), cyan, 3, cv2.LINE_AA)
        cv2.line(frame, (x,y), (x,y + sy*corner), cyan, 3, cv2.LINE_AA)
    # Reticle di tengah wajah dan garis scan.
    cv2.circle(frame, (cx, cy), max(8, int(min(bw,bh)*0.12)), blue, 1, cv2.LINE_AA)
    cv2.line(frame, (cx-9, cy), (cx+9, cy), cyan, 1, cv2.LINE_AA)
    cv2.line(frame, (cx, cy-9), (cx, cy+9), cyan, 1, cv2.LINE_AA)
    cv2.putText(frame, "FACE ID: TRACKED", (x1, max(18, y1-9)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, cyan, 1, cv2.LINE_AA)
    cv2.putText(frame, f"HOLO ZOOM {scale:.1f}x", (x1, min(h-8, y2+18)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, blue, 1, cv2.LINE_AA)
    return (x1, y1, x2, y2)



def draw_magic_finger_effect(frame, hand_landmarks, timestamp=None):
    """Overlay bunga neon dan partikel love pada titik finger-heart."""
    if timestamp is None:
        timestamp = time.time()
    h, w = frame.shape[:2]
    thumb = hand_landmarks.landmark[4]
    index = hand_landmarks.landmark[8]
    cx = int(((thumb.x + index.x) * 0.5) * w)
    cy = int(((thumb.y + index.y) * 0.5) * h)

    # Animasi berdenyut dan berputar agar efek terasa hidup.
    pulse = 1.0 + 0.12 * math.sin(timestamp * 7.0)
    rotation = timestamp * 1.8
    radius = int(10 * pulse)
    petal_radius = int(9 * pulse)
    pink = (210, 90, 255)
    hot_pink = (170, 55, 255)
    gold = (40, 220, 255)
    white = (245, 245, 255)

    # Halo luar dan cincin hologram.
    cv2.circle(frame, (cx, cy), int(29 * pulse), (180, 70, 255), 1, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy), int(23 * pulse), (255, 150, 240), 1, cv2.LINE_AA)

    # Enam kelopak bunga yang berputar perlahan.
    for k in range(6):
        angle = rotation + (2.0 * math.pi * k / 6.0)
        px = int(cx + math.cos(angle) * 15 * pulse)
        py = int(cy + math.sin(angle) * 15 * pulse)
        cv2.circle(frame, (px, py), petal_radius, pink, -1, cv2.LINE_AA)
        cv2.circle(frame, (px, py), petal_radius, white, 1, cv2.LINE_AA)

    cv2.circle(frame, (cx, cy), radius, gold, -1, cv2.LINE_AA)
    cv2.circle(frame, (cx, cy), radius, white, 1, cv2.LINE_AA)

    # Sparkle kecil di sekitar bunga.
    for k in range(4):
        angle = -rotation * 1.4 + (math.pi / 2.0 * k)
        sx = int(cx + math.cos(angle) * 36 * pulse)
        sy = int(cy + math.sin(angle) * 36 * pulse)
        cv2.line(frame, (sx-4, sy), (sx+4, sy), white, 1, cv2.LINE_AA)
        cv2.line(frame, (sx, sy-4), (sx, sy+4), white, 1, cv2.LINE_AA)

    label_y = max(22, cy - 48)
    cv2.putText(frame, "MAGIC LOVE", (max(4, cx-43), label_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (220, 150, 255), 1, cv2.LINE_AA)



def is_l_frame_hand(hand_landmarks):
    """Deteksi pose L berdasarkan ekstensi jari yang dinormalisasi ukuran telapak."""
    lm = hand_landmarks.landmark
    scale = _skala_telapak(lm)
    index_extended = _jari_lurus(lm, 8, 6)
    middle_curled = not _jari_lurus(lm, 12, 10)
    ring_curled = not _jari_lurus(lm, 16, 14)
    pinky_curled = not _jari_lurus(lm, 20, 18)
    thumb_open = _jarak_lm(lm[4], lm[5]) / scale > 1.0
    return index_extended and thumb_open and middle_curled and ring_curled and pinky_curled


def draw_hand_frame_ar(frame, source_frame, face_box, hand_landmarks_list):
    """Proyeksikan crop wajah ke quadrilateral yang dibentuk dua tangan pose L."""
    if len(hand_landmarks_list) < 2:
        return False
    # Urutkan tangan berdasarkan posisi pergelangan pada gambar yang sudah di-mirror.
    hands = sorted(hand_landmarks_list, key=lambda h: h.landmark[0].x)
    if not (is_l_frame_hand(hands[0]) and is_l_frame_hand(hands[1])):
        return False

    h, w = frame.shape[:2]
    def xy(hand, idx):
        lm = hand.landmark[idx]
        return [int(np.clip(lm.x * w, 0, w - 1)), int(np.clip(lm.y * h, 0, h - 1))]

    # Sudut atas berasal dari telunjuk; sudut bawah dari ibu jari.
    left_top, left_bottom = xy(hands[0], 8), xy(hands[0], 4)
    right_top, right_bottom = xy(hands[1], 8), xy(hands[1], 4)
    dst = np.float32([left_top, right_top, right_bottom, left_bottom])

    # Tolak frame yang terlalu kecil, terbalik, atau hampir kolaps.
    area = abs(cv2.contourArea(dst.astype(np.int32)))
    if area < 4500:
        return False

    # Gambar wajah ke dalam bidang tangan. Bila wajah belum terdeteksi,
    # gunakan area tengah kamera sebagai sumber sementara.
    if face_box is not None:
        x1, y1, x2, y2 = face_box
    else:
        x1, y1, x2, y2 = int(w*0.30), int(h*0.12), int(w*0.70), int(h*0.88)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    crop = source_frame[y1:y2, x1:x2]
    if crop.size == 0:
        return False

    ch, cw = crop.shape[:2]
    src = np.float32([[0, 0], [cw-1, 0], [cw-1, ch-1], [0, ch-1]])
    matrix = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(crop, matrix, (w, h))
    mask_src = np.full((ch, cw), 255, dtype=np.uint8)
    mask = cv2.warpPerspective(mask_src, matrix, (w, h))
    mask3 = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    # Campurkan gambar wajah secara transparan ke area frame.
    frame[:] = np.where(mask3 > 0, cv2.addWeighted(frame, 0.22, warped, 0.78, 0), frame)

    polygon = dst.astype(np.int32).reshape((-1, 1, 2))
    cyan = (255, 235, 50)
    pink = (220, 80, 255)
    cv2.polylines(frame, [polygon], True, cyan, 3, cv2.LINE_AA)
    cv2.polylines(frame, [polygon], True, pink, 1, cv2.LINE_AA)
    for px, py in dst.astype(np.int32):
        cv2.circle(frame, (int(px), int(py)), 8, cyan, 2, cv2.LINE_AA)
        cv2.circle(frame, (int(px), int(py)), 3, (255, 255, 255), -1, cv2.LINE_AA)
    cv2.putText(frame, "HAND FRAME AR | MOVE BOTH HANDS",
                (max(8, int(dst[:,0].min())), max(22, int(dst[:,1].min())-12)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, cyan, 1, cv2.LINE_AA)
    return True

def get_gesture_name(mode):
    labels = {
        1: "TELAPAK TERBUKA | BLUE COSMOS",
        2: "TELUNJUK | SATURNUS",
        3: "PEACE | I LOVE YOU",
        4: "KEPALAN | PINK HEART",
        5: "JEMPOL | CREATED BY VIRDA AYU",
        6: "TIGA JARI | RAINBOW GALAXY",
        7: "DUA TELAPAK DEKAT | CLAP BURST",
        8: "FINGER HEART | MAGIC FINGER"
    }
    return labels.get(mode, "GESTURE TIDAK DIKENALI")


def camera_thread_func():
    # Backend DirectShow biasanya memberi latensi lebih rendah di Windows.
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap = cv2.VideoCapture(0)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    mp_hands = mp.solutions.hands
    mp_face = mp.solutions.face_mesh

    hands = mp_hands.Hands(
        max_num_hands=2,
        model_complexity=0,
        min_detection_confidence=0.52,
        min_tracking_confidence=0.52
    )

    # FaceMesh hanya diproses ketika gesture bingkai sudah stabil.
    face_mesh = mp_face.FaceMesh(
        max_num_faces=1,
        refine_landmarks=False,
        min_detection_confidence=0.52,
        min_tracking_confidence=0.52
    )

    gesture_history = deque(maxlen=5)
    frame_history = deque(maxlen=4)
    active_mode = 1
    frame_active = False
    missing_frame_count = 0
    smoothed_x, smoothed_y, smoothed_z = 0.0, 0.0, -12.0
    holo_scale = 1.0
    last_valid_gesture_time = time.time()

    try:
        while shared_data["running"]:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue

            frame = cv2.flip(frame, 1)
            source_frame = frame.copy()
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            rgb_frame.flags.writeable = False
            hand_results = hands.process(rgb_frame)
            rgb_frame.flags.writeable = True

            detected_hands = hand_results.multi_hand_landmarks or []
            face_box = None
            face_detected = False
            gesture_name = "MENUNGGU TANGAN"
            local_mode = active_mode
            face_tracking_active = False

            for hand_lm in detected_hands:
                mp.solutions.drawing_utils.draw_landmarks(
                    frame, hand_lm, mp_hands.HAND_CONNECTIONS
                )

            # Gesture bingkai harus terdeteksi beberapa frame berturut-turut
            # agar Face Tracking tidak berkedip akibat deteksi yang sesaat hilang.
            raw_frame_gesture = (
                len(detected_hands) == 2
                and is_l_frame_hand(detected_hands[0])
                and is_l_frame_hand(detected_hands[1])
            )
            frame_history.append(1 if raw_frame_gesture else 0)

            if raw_frame_gesture:
                missing_frame_count = 0
            else:
                missing_frame_count += 1

            if sum(frame_history) >= 3:
                frame_active = True
            elif missing_frame_count >= 4:
                frame_active = False

            # Face tracking aktif hanya pada pose bingkai yang telah stabil.
            if frame_active:
                face_tracking_active = True
                face_results = face_mesh.process(rgb_frame)

                if face_results.multi_face_landmarks:
                    face_detected = True
                    face_lm = face_results.multi_face_landmarks[0]
                    face_box = draw_hologram_face(frame, face_lm, holo_scale)

                    # Jarak pinch kedua tangan mengatur skala secara halus.
                    pinch_values = [
                        _jarak_lm(h.landmark[4], h.landmark[8]) /
                        _skala_telapak(h.landmark)
                        for h in detected_hands
                    ]
                    pinch_avg = sum(pinch_values) / len(pinch_values)
                    desired_scale = float(np.clip(1.35 - pinch_avg * 0.20, 0.9, 1.3))
                    holo_scale += (desired_scale - holo_scale) * 0.10
                else:
                    cv2.putText(
                        frame, "FACE ID: SEARCHING...",
                        (12, 78), cv2.FONT_HERSHEY_SIMPLEX,
                        0.48, (0, 180, 255), 1, cv2.LINE_AA
                    )

                draw_hand_frame_ar(frame, source_frame, face_box, detected_hands)
                gesture_name = "HAND FRAME | FACE TRACKING ON"

            else:
                # Prioritas dua tangan: clap jika jarak telapak relatif kecil.
                raw_mode = 0
                if len(detected_hands) == 2:
                    scale_avg = (
                        _skala_telapak(detected_hands[0].landmark) +
                        _skala_telapak(detected_hands[1].landmark)
                    ) / 2.0
                    palm_distance = jarak_tengah_telapak(
                        detected_hands[0], detected_hands[1]
                    )
                    if palm_distance / max(scale_avg, 0.04) < 2.15:
                        raw_mode = 7
                    else:
                        modes = [hitung_mode_gestur(h) for h in detected_hands]
                        valid_modes = [m for m in modes if m != 0]
                        raw_mode = 8 if 8 in valid_modes else (
                            valid_modes[0] if valid_modes else 0
                        )
                elif len(detected_hands) == 1:
                    raw_mode = hitung_mode_gestur(detected_hands[0])

                if raw_mode:
                    gesture_history.append(raw_mode)
                    last_valid_gesture_time = time.time()

                # Majority vote mengurangi perpindahan mode yang terlalu cepat.
                if gesture_history:
                    counts = Counter(gesture_history)
                    candidate, votes = counts.most_common(1)[0]
                    if votes >= 3:
                        active_mode = candidate
                # Kembali ke Blue Cosmos jika tangan hilang cukup lama.
                elif time.time() - last_valid_gesture_time > 0.8:
                    active_mode = 1

                local_mode = active_mode
                gesture_name = (
                    get_gesture_name(local_mode)
                    if detected_hands else "MENUNGGU GESTURE"
                )

                # Magic Finger tetap berjalan ketika Face Tracking OFF.
                if detected_hands:
                    for hand_lm in detected_hands:
                        if hitung_mode_gestur(hand_lm) == 8:
                            draw_magic_finger_effect(frame, hand_lm)

            # Smoothing posisi agar partikel tidak bergetar mengikuti landmark.
            if detected_hands:
                wrist = detected_hands[0].landmark[0]
                desired_x = (wrist.x - 0.5) * 10.0
                desired_y = -(wrist.y - 0.5) * 7.0
                palm_width = _jarak_lm(
                    detected_hands[0].landmark[0],
                    detected_hands[0].landmark[17]
                )
                desired_z = -10.0 - (1.0 / (palm_width + 0.02)) * 0.16
                alpha = 0.22
                smoothed_x += (desired_x - smoothed_x) * alpha
                smoothed_y += (desired_y - smoothed_y) * alpha
                smoothed_z += (desired_z - smoothed_z) * alpha
            else:
                smoothed_x *= 0.92
                smoothed_y *= 0.92
                smoothed_z += (-12.0 - smoothed_z) * 0.08

            face_status = "FACE TRACKING: ON" if face_tracking_active else "FACE TRACKING: OFF"
            status_color = (80, 255, 120) if face_tracking_active else (150, 150, 150)
            cv2.putText(
                frame, face_status, (12, 27),
                cv2.FONT_HERSHEY_SIMPLEX, 0.52, status_color, 2, cv2.LINE_AA
            )
            cv2.putText(
                frame, "GESTURE: " + gesture_name, (12, 52),
                cv2.FONT_HERSHEY_SIMPLEX, 0.40, (255, 230, 40), 1, cv2.LINE_AA
            )
            cv2.putText(
                frame, "MAKE TWO L SHAPES TO ACTIVATE FACE AR | Q: QUIT",
                (12, frame.shape[0] - 14),
                cv2.FONT_HERSHEY_SIMPLEX, 0.34, (255, 230, 40), 1, cv2.LINE_AA
            )

            with lock:
                shared_data["mode"] = local_mode
                shared_data["target_x"] = smoothed_x
                shared_data["target_y"] = smoothed_y
                shared_data["target_z"] = smoothed_z
                shared_data["frame"] = frame
                shared_data["face_box"] = face_box
                shared_data["face_scale"] = holo_scale
                shared_data["face_detected"] = face_detected
                shared_data["face_tracking_active"] = face_tracking_active
                shared_data["gesture_name"] = gesture_name

    finally:
        hands.close()
        face_mesh.close()
        cap.release()


# Jalankan Thread Kamera terlebih dahulu
camera_thread = threading.Thread(target=camera_thread_func, daemon=True)
camera_thread.start()

# Berikan jeda 1 detik agar kamera macOS siap sebelum Pygame mengambil alih GUI utama
time.sleep(1.0)

# ==========================================
# MAIN THREAD: RENDERING GRAFIS 3D (Pygame diinisialisasi di sini)
# ==========================================
pygame.init()
pygame.display.set_mode((WIDTH, HEIGHT), DOUBLEBUF | OPENGL)
pygame.display.set_caption("NebulaHeart 3D - Gesture Controlled AR | Created by Virda Ayu")

glMatrixMode(GL_PROJECTION)
glLoadIdentity()
gluPerspective(45, (WIDTH / HEIGHT), 0.1, 50.0)
glMatrixMode(GL_MODELVIEW)
glEnable(GL_DEPTH_TEST)

clock = pygame.time.Clock()
rotation_angle = 0.0
hand_x, hand_y, hand_z = 0.0, 0.0, -12.0

while shared_data["running"]:
    pygame.event.pump()
    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
            shared_data["running"] = False

    with lock:
        current_mode = shared_data["mode"]
        target_hand_x = shared_data["target_x"]
        target_hand_y = shared_data["target_y"]
        target_hand_z = shared_data["target_z"]
        frame = shared_data["frame"].copy() if shared_data["frame"] is not None else None

    if frame is not None:
        mode_labels = {
            1: "ROTASI ANGCOSMOS (Terbuka)", 
            2: "SATURNUS 3D (Satu Jari)", 
            3: "TEKS I LOVE YOU (Peace)", 
            4: "BENTUK HATI / LOVE (Kepal)",
            5: "CREATED BY VIRDA AYU (Jempol ke atas)",
            6: "SPIRAL PELANGI (Tiga jari)",
            7: "CLAP BURST (Kedua tangan mendekat)",
            8: "FINGER LOVE + MAGIC FLOWER (Jempol + telunjuk)"
        }
        cv2.putText(frame, f"MODE: {mode_labels[current_mode]}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 255, 0), 2)
        cv2.imshow("NebulaHeart AR - Gesture & Face Monitor", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            shared_data["running"] = False

    glClearColor(0.0, 0.0, 0.0, 1.0)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    hand_x += (target_hand_x - hand_x) * 0.25
    hand_y += (target_hand_y - hand_y) * 0.25
    hand_z += (target_hand_z - hand_z) * 0.25

    if current_mode == 1:
        target_pos = pos_space
        rotation_angle += 0.5 
    elif current_mode == 2:
        target_pos = pos_planet
        rotation_angle += 2.0 
    elif current_mode == 3:
        target_pos = pos_text
        rotation_angle = 0.0  
    elif current_mode == 4:
        target_pos = pos_heart
        rotation_angle += 1.5
    elif current_mode == 5:
        target_pos = pos_virda
        rotation_angle = 0.0
    elif current_mode == 6:
        target_pos = pos_rainbow
        rotation_angle += 1.2
    elif current_mode == 7:
        target_pos = pos_clap
        rotation_angle += 2.8
    elif current_mode == 8:
        target_pos = pos_finger_heart
        rotation_angle += 0.35

    current_pos += (target_pos - current_pos) * 0.15

    if current_mode in [2, 3, 4, 5, 6, 7, 8]:
        glTranslatef(hand_x, hand_y, hand_z)
        if current_mode == 2:
            glRotatef(25, 1.0, 0.0, 0.5)
    else:
        glTranslatef(0.0, 0.0, -12.0)
    
    glRotatef(rotation_angle, 0.0, 1.0, 0.0)

    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glPointSize(4.5)  
    
    glBegin(GL_POINTS)
    for i in range(NUM_PARTICLES):
        if current_mode == 3:
            glColor4f(0.0, 0.8, 1.0, 0.9)  
        elif current_mode == 4:
            glColor4f(1.0, 0.1, 0.4, 0.95)
        elif current_mode == 5:
            glColor4f(0.2, 0.9, 1.0, 0.95)
        elif current_mode == 7:
            pulse = 0.65 + 0.3 * abs(math.sin(time.time() * 5.0))
            glColor4f(1.0, pulse, 0.25, 0.95)
        elif current_mode == 8:
            glColor4f(1.0, 0.18, 0.48, 0.98)
        elif current_mode == 6:
            # Gradasi warna pelangi berdasarkan indeks partikel
            hue = (i / NUM_PARTICLES)
            # HSV sederhana -> RGB
            h6 = hue * 6.0
            x6 = 1.0 - abs((h6 % 2.0) - 1.0)
            if h6 < 1.0: rgb = (1.0, x6, 0.0)
            elif h6 < 2.0: rgb = (x6, 1.0, 0.0)
            elif h6 < 3.0: rgb = (0.0, 1.0, x6)
            elif h6 < 4.0: rgb = (0.0, x6, 1.0)
            elif h6 < 5.0: rgb = (x6, 0.0, 1.0)
            else: rgb = (1.0, 0.0, x6)
            glColor4f(rgb[0], rgb[1], rgb[2], 0.95)
        elif current_mode == 2 and i >= NUM_SPHERE:
            glColor4f(1.0, 0.7, 0.3, 0.6)  
        elif current_mode == 2 and i < NUM_SPHERE:
            glColor4f(1.0, 0.5, 0.0, 0.85) 
        else:
            glColor4f(0.1, 0.5, 1.0, 0.8)  
            
        glVertex3f(current_pos[i, 0], current_pos[i, 1], current_pos[i, 2])
    glEnd()

    pygame.display.flip()
    clock.tick(60)

shared_data["running"] = False
camera_thread.join(timeout=2.0)
cv2.destroyAllWindows()
pygame.quit()