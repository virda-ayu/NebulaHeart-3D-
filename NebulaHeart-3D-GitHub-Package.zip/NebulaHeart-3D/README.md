# NebulaHeart 3D — Space Gesture Controller

**A real-time 3D particle experience controlled by hand gestures, with an optional Face Tracking / Hand Frame AR mode.**

Created by **Virda Ayu**.

NebulaHeart 3D combines Python, OpenCV, MediaPipe, Pygame, and OpenGL to turn webcam hand gestures into interactive 3D particle formations.

> This repository contains an experimental desktop prototype. Gesture recognition and performance may vary with camera quality, lighting, hand position, and hardware.

## Features

- Real-time hand landmark detection using MediaPipe Hands.
- Eight gesture-controlled particle modes.
- Responsive gesture classification with temporal voting and smoothed hand position.
- Optional Face Tracking: activated by making an L-shaped frame with **both hands**.
- Hand Frame AR overlay and face HUD while the frame gesture is active.
- Magic Finger flower/sparkle overlay for the finger-heart gesture.
- 3D particle rendering with Pygame and PyOpenGL.

## Gesture controls

| Gesture | Action |
|---|---|
| Open palm | Blue Cosmos |
| Index finger | Saturn |
| Peace sign (two fingers) | “I LOVE YOU” |
| Fist | Pink Heart |
| Thumbs up | “CREATED BY VIRDA AYU” |
| Three fingers (index, middle, ring) | Rainbow Galaxy |
| Bring both palms close together | Clap Burst |
| Finger heart (thumb + index pinch) | Magic Finger / particle heart |
| Make an L shape with each hand to form a frame | Activate Face Tracking / Hand Frame AR |

**Face Tracking behavior:** FaceMesh is processed only while the two-hand frame gesture is recognized. Hand tracking remains active when Face Tracking is off.

## Preview

Add your own screenshots or demo recording to `assets/screenshots/` or `assets/demo/`, then link them here. For example:

```markdown
![NebulaHeart 3D preview](assets/screenshots/nebulaheart-preview.png)
```

## Requirements

- Windows 10/11 recommended (the camera capture code first tries DirectShow).
- Python **3.11** recommended.
- A working webcam.
- A graphics driver that supports OpenGL.
- The Python packages listed in [`requirements.txt`](requirements.txt).

## Installation

### Option A — Windows with Conda

```bash
conda create -n space_gesture python=3.11 -y
conda activate space_gesture
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Option B — Python virtual environment

```bash
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run

From the repository folder:

```bash
python index_virda_ar_hologram_responsive.py
```

Allow camera access if Windows asks for permission. Place your hand(s) fully inside the camera view and use clear, steady gestures.

- Press **Q** in the webcam preview window to quit.
- Press **Esc** in the 3D window to quit.

## Tips for better recognition

1. Use even, bright lighting.
2. Keep the full hand visible in the webcam frame.
3. Avoid busy backgrounds where possible.
4. Hold each gesture steadily for a short moment so temporal voting can confirm it.
5. For Hand Frame AR, keep both hands visible and form a clear L shape with each hand.

## Project structure

```text
NebulaHeart-3D/
├── index_virda_ar_hologram_responsive.py
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── CONTRIBUTING.md
└── assets/
    ├── screenshots/
    └── demo/
```

## Privacy

The application uses your webcam for local hand and (when activated) face landmark processing. The current prototype does not intentionally upload camera frames to a remote server. Do not publish recordings or screenshots containing other people without their permission.

## Known limitations

- This is a prototype; gesture thresholds may need tuning for different users, camera angles, and lighting.
- Face Tracking depends on a clear two-hand L-frame gesture and a detectable face.
- OpenGL availability and webcam backend behavior depend on the operating system and hardware.
- The project has been syntax-checked, but runtime behavior should be tested on the target computer.

## License

Released under the MIT License. See [`LICENSE`](LICENSE).

## Credits

Created by **Virda Ayu**.
